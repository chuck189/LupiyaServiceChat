# Build & Run

```
dotnet restore
dotnet watch run
```
